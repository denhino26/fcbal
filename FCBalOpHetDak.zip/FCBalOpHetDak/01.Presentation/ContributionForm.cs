﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace FCBalOpHetDak._01.Presentation
{
    public partial class ContributionForm : Form
    {
        private string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\denni\\source\\repos\\FCBalOpHetDak\\FCBalOpHetDak\\03.Database\\DatabaseFcBalOpHetDak.mdf;Integrated Security=True;Connect Timeout=30";

        public ContributionForm()
        {
            InitializeComponent();
        }

        private void ContributionForm_Load(object sender, EventArgs e)
        {
            this.contributionTableAdapter.Fill(this.databaseFcBalOpHetDakDataSet1.Contribution);
            LoadMembers();
            LoadContributions();

            comboBoxPayAmount.DataSource = new List<decimal>(TeamManager.BetalingVerwerken);
            comboBoxMember.SelectedIndex = -1;
            comboBoxPayAmount.SelectedIndex = -1;
        }

        private void LoadMembers()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT ID, Naam FROM Member";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                comboBoxMember.DataSource = dt;
                comboBoxMember.DisplayMember = "Naam";
                comboBoxMember.ValueMember = "ID";
            }
        }

        private void LoadContributions()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT ID, LidID, Bedrag, Betaaldatum, Status FROM Contribution";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridViewContributions.DataSource = dt;
            }
        }

        private void buttonBackToMain_Click(object sender, EventArgs e)
        {
            MainMenuForm mainMenu = new MainMenuForm();
            mainMenu.Show();
            this.Hide();
        }

        private void buttonPay_Click(object sender, EventArgs e)
        {
            if (comboBoxMember.SelectedItem == null || comboBoxPayAmount.SelectedItem == null)
            {
                MessageBox.Show("Selecteer een lid en een bedrag.");
                return;
            }

            int lidID = (int)comboBoxMember.SelectedValue;
            decimal betaling = Convert.ToDecimal(comboBoxPayAmount.SelectedItem);

            Contributiebetaling contributiebetaling = new Contributiebetaling(0, lidID, betaling, connectionString);
            contributiebetaling.BetaalContributie();

            LoadContributions();  
        }
    }
}
