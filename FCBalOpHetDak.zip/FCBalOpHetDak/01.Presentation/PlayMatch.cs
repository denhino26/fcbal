﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace FCBalOpHetDak._01.Presentation
{
    public partial class PlayMatch : Form
    {
        private string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\denni\\source\\repos\\FCBalOpHetDak\\FCBalOpHetDak\\03.Database\\DatabaseFcBalOpHetDak.mdf;Integrated Security=True;Connect Timeout=30";


        public PlayMatch()
        {
            InitializeComponent();
        }

        private void WedstrijdInplannen_Load(object sender, EventArgs e)
        {
            LoadMatchData();
            // TODO: This line of code loads data into the 'databaseFcBalOpHetDakDataSet1.Match' table. You can move, or remove it, as needed.
            this.matchTableAdapter.Fill(this.databaseFcBalOpHetDakDataSet1.Match);


            comboBoxTeam.DataSource = new List<string>(TeamManager.Teams);
            comboBoxOpponent.DataSource = new List<string>(TeamManager.Teams);

            comboBoxField.DataSource = new List<string>(TeamManager.Fields);

            comboBoxTime.DataSource = new List<string>(TeamManager.Time);


            comboBoxTeam.SelectedIndex = -1;
            comboBoxOpponent.SelectedIndex = -1;
            comboBoxField.SelectedIndex = -1;
            comboBoxTime.SelectedIndex = -1;


            dateTimePickerMatchday.Value = DateTime.Now;

        }

        private void LoadMatchData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {

                conn.Open();
                string query = "SELECT ID, Datum, Tijdstip, Tegenstander, Team, Veld FROM Match";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

            }
        }

        private void buttonMatchday_Click(object sender, EventArgs e)
        {
            if (comboBoxOpponent.SelectedItem == null || comboBoxTeam.SelectedItem == null || comboBoxField.SelectedItem == null)
            {
                MessageBox.Show("Selecteer een team, tegenstander en veld.");
                return;
            }

            string team = comboBoxTeam.SelectedItem.ToString();
            string tegenstander = comboBoxOpponent.SelectedItem.ToString();
            string veld = comboBoxField.SelectedItem.ToString();
            string tijdstip = comboBoxTime.SelectedItem.ToString();
            DateTime datum = dateTimePickerMatchday.Value.Date;



            MatchClass nieuweWedstrijd = new MatchClass(datum, tijdstip, tegenstander, team, veld);


            if (!MatchClass.speelschemaBijhouden(nieuweWedstrijd))
            {
                return;
            }

           
            using (SqlConnection conn = new SqlConnection(connectionString))
            {

                conn.Open();
                string query = "INSERT INTO Match ( Datum, Tijdstip, Tegenstander, Team, Veld) VALUES ( @Datum, @Tijdstip, @Tegenstander, @Team, @Veld)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {

                    cmd.Parameters.AddWithValue("@Datum", datum);
                    cmd.Parameters.AddWithValue("@Tijdstip", tijdstip);
                    cmd.Parameters.AddWithValue("@Tegenstander", tegenstander);
                    cmd.Parameters.AddWithValue("@Team", team);
                    cmd.Parameters.AddWithValue("@Veld", veld);

                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Wedstrijd succesvol ingepland!");
                LoadMatchData();

            }
        }

        

        private void buttonBackToMain_Click_1(object sender, EventArgs e)
        {
            MainMenuForm mainMenu = new MainMenuForm();
            mainMenu.Show();
            this.Hide();
        }
    }
}
