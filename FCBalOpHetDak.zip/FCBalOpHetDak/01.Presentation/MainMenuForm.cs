﻿using FCBalOpHetDak._01.Presentation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FCBalOpHetDak
{
    public partial class MainMenuForm : Form
    {

        public List<Lid> leden = new List<Lid>();
        
        public MainMenuForm()
        {
            InitializeComponent();

        }



        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonLeden_Click(object sender, EventArgs e)
        {
           MemberForm ledenForm = new MemberForm();   
            ledenForm.Show();
            this.Hide();

        }

        private void buttonWedstrijden_Click(object sender, EventArgs e)
        {
            MatchdayForm wedstrijdenForm = new MatchdayForm();
            wedstrijdenForm.Show();
            this.Hide();

        }

        private void buttonWedstrijdInplannen_Click(object sender, EventArgs e)
        {
            PlayMatch wedstrijdInplannen = new PlayMatch();
            wedstrijdInplannen.Show();
            this.Hide();

        }

        private void buttonContribution_Click(object sender, EventArgs e)
        {
            ContributionForm Contribution = new ContributionForm();
            Contribution.Show();
            this.Hide();
        }
    }
}
