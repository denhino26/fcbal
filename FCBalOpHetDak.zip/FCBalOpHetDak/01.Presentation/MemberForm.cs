﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Metrics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace FCBalOpHetDak
{
    public partial class MemberForm : Form
    {
        private string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\denni\\source\\repos\\FCBalOpHetDak\\FCBalOpHetDak\\03.Database\\DatabaseFcBalOpHetDak.mdf;Integrated Security=True;Connect Timeout=30";


        public MemberForm()
        {
            InitializeComponent();
        }

       

        private void buttonBackToMain_Click(object sender, EventArgs e)
        {
            MainMenuForm mainMenu = new MainMenuForm();
            mainMenu.Show();
            this.Hide();
        }

        private void LedenForm_Load(object sender, EventArgs e)
        {
        


            comboBoxTeam.DataSource = new List<string>(TeamManager.Teams);
            comboBoxTeam.SelectedIndex = -1;
            LoadMemberData();

        }

        private void LoadMemberData()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT ID, Naam, Geboortejaar, Email ,Team, Status FROM Member";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dataGridViewMembers.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fout bij het laden van de data: " + ex.Message);
            }
        }


        private void buttonAddMember_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(textBoxAge.Text, out int geboortejaar))
            {
                MessageBox.Show("Vul een geldig geboortejaar in.");
                return;
            }

            string naam = textBoxName.Text;
            string email = textBoxEmail.Text;
            string team = comboBoxTeam.SelectedItem?.ToString();

            Lid nieuwLid = new Lid();
            nieuwLid.NewMember(naam, geboortejaar, email, team);

          
            textBoxName.Clear();
            textBoxAge.Clear();
            textBoxEmail.Clear();
            comboBoxTeam.SelectedIndex = -1;

            LoadMemberData();
        }

    }
}
