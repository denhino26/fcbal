﻿namespace FCBalOpHetDak._01.Presentation
{
    partial class ContributionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonBackToMain = new System.Windows.Forms.Button();
            this.contributionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboBoxPayAmount = new System.Windows.Forms.ComboBox();
            this.comboBoxMember = new System.Windows.Forms.ComboBox();
            this.labelAmount = new System.Windows.Forms.Label();
            this.lbName = new System.Windows.Forms.Label();
            this.buttonPay = new System.Windows.Forms.Button();
            this.databaseFcBalOpHetDakDataSet = new FCBalOpHetDak.DatabaseFcBalOpHetDakDataSet();
            this.databaseFcBalOpHetDakDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewContributions = new System.Windows.Forms.DataGridView();
            //this.databaseFcBalOpHetDakDataSet1 = new FCBalOpHetDak.DatabaseFcBalOpHetDakDataSet1();
            this.contributionBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.contributionTableAdapter = new FCBalOpHetDak.DatabaseFcBalOpHetDakDataSet1TableAdapters.ContributionTableAdapter();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.contributionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseFcBalOpHetDakDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseFcBalOpHetDakDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewContributions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseFcBalOpHetDakDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.contributionBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonBackToMain
            // 
            this.buttonBackToMain.Location = new System.Drawing.Point(764, 244);
            this.buttonBackToMain.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonBackToMain.Name = "buttonBackToMain";
            this.buttonBackToMain.Size = new System.Drawing.Size(163, 62);
            this.buttonBackToMain.TabIndex = 7;
            this.buttonBackToMain.Text = "Terug ";
            this.buttonBackToMain.UseVisualStyleBackColor = true;
            this.buttonBackToMain.Click += new System.EventHandler(this.buttonBackToMain_Click);
            // 
            // contributionBindingSource
            // 
            this.contributionBindingSource.DataMember = "Contribution";
            // 
            // comboBoxPayAmount
            // 
            this.comboBoxPayAmount.FormattingEnabled = true;
            this.comboBoxPayAmount.Location = new System.Drawing.Point(128, 72);
            this.comboBoxPayAmount.Name = "comboBoxPayAmount";
            this.comboBoxPayAmount.Size = new System.Drawing.Size(191, 24);
            this.comboBoxPayAmount.TabIndex = 33;
            // 
            // comboBoxMember
            // 
            this.comboBoxMember.FormattingEnabled = true;
            this.comboBoxMember.Location = new System.Drawing.Point(128, 27);
            this.comboBoxMember.Name = "comboBoxMember";
            this.comboBoxMember.Size = new System.Drawing.Size(191, 24);
            this.comboBoxMember.TabIndex = 32;
            // 
            // labelAmount
            // 
            this.labelAmount.AutoSize = true;
            this.labelAmount.Location = new System.Drawing.Point(3, 72);
            this.labelAmount.Name = "labelAmount";
            this.labelAmount.Size = new System.Drawing.Size(96, 16);
            this.labelAmount.TabIndex = 30;
            this.labelAmount.Text = "Betaal bedrag:";
            // 
            // lbName
            // 
            this.lbName.AutoSize = true;
            this.lbName.Location = new System.Drawing.Point(52, 27);
            this.lbName.Name = "lbName";
            this.lbName.Size = new System.Drawing.Size(47, 16);
            this.lbName.TabIndex = 29;
            this.lbName.Text = "Naam:";
            // 
            // buttonPay
            // 
            this.buttonPay.Location = new System.Drawing.Point(103, 152);
            this.buttonPay.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonPay.Name = "buttonPay";
            this.buttonPay.Size = new System.Drawing.Size(216, 37);
            this.buttonPay.TabIndex = 28;
            this.buttonPay.Text = "Betalen";
            this.buttonPay.UseVisualStyleBackColor = true;
            this.buttonPay.Click += new System.EventHandler(this.buttonPay_Click);
            // 
            // databaseFcBalOpHetDakDataSet
            // 
            this.databaseFcBalOpHetDakDataSet.DataSetName = "DatabaseFcBalOpHetDakDataSet";
            this.databaseFcBalOpHetDakDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // databaseFcBalOpHetDakDataSetBindingSource
            // 
            this.databaseFcBalOpHetDakDataSetBindingSource.DataSource = this.databaseFcBalOpHetDakDataSet;
            this.databaseFcBalOpHetDakDataSetBindingSource.Position = 0;
            // 
            // dataGridViewContributions
            // 
            this.dataGridViewContributions.AutoGenerateColumns = false;
            this.dataGridViewContributions.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewContributions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewContributions.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.dataGridViewContributions.DataSource = this.contributionBindingSource1;
            this.dataGridViewContributions.Location = new System.Drawing.Point(433, 27);
            this.dataGridViewContributions.Name = "dataGridViewContributions";
            this.dataGridViewContributions.RowHeadersWidth = 51;
            this.dataGridViewContributions.RowTemplate.Height = 24;
            this.dataGridViewContributions.Size = new System.Drawing.Size(564, 150);
            this.dataGridViewContributions.TabIndex = 34;
            // 
            // databaseFcBalOpHetDakDataSet1
            // 
            this.databaseFcBalOpHetDakDataSet1.DataSetName = "DatabaseFcBalOpHetDakDataSet1";
            this.databaseFcBalOpHetDakDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // contributionBindingSource1
            // 
            this.contributionBindingSource1.DataMember = "Contribution";
            this.contributionBindingSource1.DataSource = this.databaseFcBalOpHetDakDataSet1;
            // 
            // contributionTableAdapter
            // 
            this.contributionTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "LidID";
            this.dataGridViewTextBoxColumn2.HeaderText = "LidID";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Bedrag";
            this.dataGridViewTextBoxColumn3.HeaderText = "Bedrag";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Betaaldatum";
            this.dataGridViewTextBoxColumn4.HeaderText = "Betaaldatum";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Status";
            this.dataGridViewTextBoxColumn5.HeaderText = "Status";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // ContributionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1121, 450);
            this.Controls.Add(this.dataGridViewContributions);
            this.Controls.Add(this.comboBoxPayAmount);
            this.Controls.Add(this.comboBoxMember);
            this.Controls.Add(this.labelAmount);
            this.Controls.Add(this.lbName);
            this.Controls.Add(this.buttonPay);
            this.Controls.Add(this.buttonBackToMain);
            this.Name = "ContributionForm";
            this.Text = "ContributionForm";
            this.Load += new System.EventHandler(this.ContributionForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.contributionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseFcBalOpHetDakDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseFcBalOpHetDakDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewContributions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseFcBalOpHetDakDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.contributionBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBackToMain;
        private System.Windows.Forms.BindingSource contributionBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lidIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bedragDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn betaaldatumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.ComboBox comboBoxPayAmount;
        private System.Windows.Forms.ComboBox comboBoxMember;
        private System.Windows.Forms.Label labelAmount;
        private System.Windows.Forms.Label lbName;
        private System.Windows.Forms.Button buttonPay;
        private DatabaseFcBalOpHetDakDataSet databaseFcBalOpHetDakDataSet;
        private System.Windows.Forms.BindingSource databaseFcBalOpHetDakDataSetBindingSource;
        private System.Windows.Forms.DataGridView dataGridViewContributions;
        private DatabaseFcBalOpHetDakDataSet1 databaseFcBalOpHetDakDataSet1;
        private System.Windows.Forms.BindingSource contributionBindingSource1;
        private DatabaseFcBalOpHetDakDataSet1TableAdapters.ContributionTableAdapter contributionTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
    }
}