﻿namespace FCBalOpHetDak
{
    partial class MainMenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonMatch = new System.Windows.Forms.Button();
            this.buttonMember = new System.Windows.Forms.Button();
            this.buttonScheduleMatch = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.buttonContribution = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonMatch
            // 
            this.buttonMatch.Location = new System.Drawing.Point(366, 94);
            this.buttonMatch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonMatch.Name = "buttonMatch";
            this.buttonMatch.Size = new System.Drawing.Size(155, 62);
            this.buttonMatch.TabIndex = 1;
            this.buttonMatch.Text = "Wedstrijden";
            this.buttonMatch.UseVisualStyleBackColor = true;
            this.buttonMatch.Click += new System.EventHandler(this.buttonWedstrijden_Click);
            // 
            // buttonMember
            // 
            this.buttonMember.Location = new System.Drawing.Point(12, 94);
            this.buttonMember.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonMember.Name = "buttonMember";
            this.buttonMember.Size = new System.Drawing.Size(163, 62);
            this.buttonMember.TabIndex = 2;
            this.buttonMember.Text = "Leden";
            this.buttonMember.UseVisualStyleBackColor = true;
            this.buttonMember.Click += new System.EventHandler(this.buttonLeden_Click);
            // 
            // buttonScheduleMatch
            // 
            this.buttonScheduleMatch.Location = new System.Drawing.Point(540, 94);
            this.buttonScheduleMatch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonScheduleMatch.Name = "buttonScheduleMatch";
            this.buttonScheduleMatch.Size = new System.Drawing.Size(149, 62);
            this.buttonScheduleMatch.TabIndex = 3;
            this.buttonScheduleMatch.Text = "Wedstrijd inplannen";
            this.buttonScheduleMatch.UseVisualStyleBackColor = true;
            this.buttonScheduleMatch.Click += new System.EventHandler(this.buttonWedstrijdInplannen_Click);
            // 
            // buttonContribution
            // 
            this.buttonContribution.Location = new System.Drawing.Point(194, 94);
            this.buttonContribution.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonContribution.Name = "buttonContribution";
            this.buttonContribution.Size = new System.Drawing.Size(155, 62);
            this.buttonContribution.TabIndex = 4;
            this.buttonContribution.Text = "Contributie";
            this.buttonContribution.UseVisualStyleBackColor = true;
            this.buttonContribution.Click += new System.EventHandler(this.buttonContribution_Click);
            // 
            // MainMenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(701, 334);
            this.Controls.Add(this.buttonContribution);
            this.Controls.Add(this.buttonScheduleMatch);
            this.Controls.Add(this.buttonMember);
            this.Controls.Add(this.buttonMatch);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "MainMenuForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button buttonMatch;
        private System.Windows.Forms.Button buttonMember;
        private System.Windows.Forms.Button buttonScheduleMatch;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button buttonContribution;
    }
}

