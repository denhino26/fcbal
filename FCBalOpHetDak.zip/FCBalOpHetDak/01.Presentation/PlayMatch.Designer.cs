﻿namespace FCBalOpHetDak._01.Presentation
{
    partial class PlayMatch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonMatchday = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxTime = new System.Windows.Forms.ComboBox();
            this.comboBoxField = new System.Windows.Forms.ComboBox();
            this.comboBoxOpponent = new System.Windows.Forms.ComboBox();
            this.comboBoxTeam = new System.Windows.Forms.ComboBox();
            this.buttonBackToMain = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.databaseFcBalOpHetDakDataSet1 = new FCBalOpHetDak.DatabaseFcBalOpHetDakDataSet1();
            this.matchBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.matchTableAdapter = new FCBalOpHetDak.DatabaseFcBalOpHetDakDataSet1TableAdapters.MatchTableAdapter();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tijdstipDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tegenstanderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.teamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.veldDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateTimePickerMatchday = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseFcBalOpHetDakDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.matchBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonMatchday
            // 
            this.buttonMatchday.Location = new System.Drawing.Point(908, 373);
            this.buttonMatchday.Name = "buttonMatchday";
            this.buttonMatchday.Size = new System.Drawing.Size(105, 53);
            this.buttonMatchday.TabIndex = 18;
            this.buttonMatchday.Text = "Toevoegen";
            this.buttonMatchday.UseVisualStyleBackColor = true;
            this.buttonMatchday.Click += new System.EventHandler(this.buttonMatchday_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(771, 194);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 16);
            this.label5.TabIndex = 17;
            this.label5.Text = "Tijd:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(771, 144);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 16);
            this.label4.TabIndex = 16;
            this.label4.Text = "Veld:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(771, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 16);
            this.label2.TabIndex = 15;
            this.label2.Text = "Uit team:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(771, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 16);
            this.label1.TabIndex = 14;
            this.label1.Text = "Thuis team:";
            // 
            // comboBoxTime
            // 
            this.comboBoxTime.FormattingEnabled = true;
            this.comboBoxTime.Location = new System.Drawing.Point(892, 194);
            this.comboBoxTime.Name = "comboBoxTime";
            this.comboBoxTime.Size = new System.Drawing.Size(121, 24);
            this.comboBoxTime.TabIndex = 13;
            // 
            // comboBoxField
            // 
            this.comboBoxField.FormattingEnabled = true;
            this.comboBoxField.Location = new System.Drawing.Point(892, 141);
            this.comboBoxField.Name = "comboBoxField";
            this.comboBoxField.Size = new System.Drawing.Size(121, 24);
            this.comboBoxField.TabIndex = 12;
            // 
            // comboBoxOpponent
            // 
            this.comboBoxOpponent.FormattingEnabled = true;
            this.comboBoxOpponent.Location = new System.Drawing.Point(892, 88);
            this.comboBoxOpponent.Name = "comboBoxOpponent";
            this.comboBoxOpponent.Size = new System.Drawing.Size(121, 24);
            this.comboBoxOpponent.TabIndex = 11;
            // 
            // comboBoxTeam
            // 
            this.comboBoxTeam.FormattingEnabled = true;
            this.comboBoxTeam.Location = new System.Drawing.Point(892, 39);
            this.comboBoxTeam.Name = "comboBoxTeam";
            this.comboBoxTeam.Size = new System.Drawing.Size(121, 24);
            this.comboBoxTeam.TabIndex = 10;
            // 
            // buttonBackToMain
            // 
            this.buttonBackToMain.Location = new System.Drawing.Point(377, 273);
            this.buttonBackToMain.Name = "buttonBackToMain";
            this.buttonBackToMain.Size = new System.Drawing.Size(175, 53);
            this.buttonBackToMain.TabIndex = 19;
            this.buttonBackToMain.Text = "Terug";
            this.buttonBackToMain.UseVisualStyleBackColor = true;
            this.buttonBackToMain.Click += new System.EventHandler(this.buttonBackToMain_Click_1);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.datumDataGridViewTextBoxColumn,
            this.tijdstipDataGridViewTextBoxColumn,
            this.tegenstanderDataGridViewTextBoxColumn,
            this.teamDataGridViewTextBoxColumn,
            this.veldDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.matchBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(710, 150);
            this.dataGridView1.TabIndex = 20;
            // 
            // databaseFcBalOpHetDakDataSet1
            // 
            this.databaseFcBalOpHetDakDataSet1.DataSetName = "DatabaseFcBalOpHetDakDataSet1";
            this.databaseFcBalOpHetDakDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // matchBindingSource
            // 
            this.matchBindingSource.DataMember = "Match";
            this.matchBindingSource.DataSource = this.databaseFcBalOpHetDakDataSet1;
            // 
            // matchTableAdapter
            // 
            this.matchTableAdapter.ClearBeforeFill = true;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // datumDataGridViewTextBoxColumn
            // 
            this.datumDataGridViewTextBoxColumn.DataPropertyName = "Datum";
            this.datumDataGridViewTextBoxColumn.HeaderText = "Datum";
            this.datumDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.datumDataGridViewTextBoxColumn.Name = "datumDataGridViewTextBoxColumn";
            // 
            // tijdstipDataGridViewTextBoxColumn
            // 
            this.tijdstipDataGridViewTextBoxColumn.DataPropertyName = "Tijdstip";
            this.tijdstipDataGridViewTextBoxColumn.HeaderText = "Tijdstip";
            this.tijdstipDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tijdstipDataGridViewTextBoxColumn.Name = "tijdstipDataGridViewTextBoxColumn";
            // 
            // tegenstanderDataGridViewTextBoxColumn
            // 
            this.tegenstanderDataGridViewTextBoxColumn.DataPropertyName = "Tegenstander";
            this.tegenstanderDataGridViewTextBoxColumn.HeaderText = "Tegenstander";
            this.tegenstanderDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tegenstanderDataGridViewTextBoxColumn.Name = "tegenstanderDataGridViewTextBoxColumn";
            // 
            // teamDataGridViewTextBoxColumn
            // 
            this.teamDataGridViewTextBoxColumn.DataPropertyName = "Team";
            this.teamDataGridViewTextBoxColumn.HeaderText = "Team";
            this.teamDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.teamDataGridViewTextBoxColumn.Name = "teamDataGridViewTextBoxColumn";
            // 
            // veldDataGridViewTextBoxColumn
            // 
            this.veldDataGridViewTextBoxColumn.DataPropertyName = "Veld";
            this.veldDataGridViewTextBoxColumn.HeaderText = "Veld";
            this.veldDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.veldDataGridViewTextBoxColumn.Name = "veldDataGridViewTextBoxColumn";
            // 
            // dateTimePickerMatchday
            // 
            this.dateTimePickerMatchday.Location = new System.Drawing.Point(761, 255);
            this.dateTimePickerMatchday.Name = "dateTimePickerMatchday";
            this.dateTimePickerMatchday.Size = new System.Drawing.Size(252, 22);
            this.dateTimePickerMatchday.TabIndex = 21;
            // 
            // WedstrijdInplannen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1088, 438);
            this.Controls.Add(this.dateTimePickerMatchday);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.buttonBackToMain);
            this.Controls.Add(this.buttonMatchday);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxTime);
            this.Controls.Add(this.comboBoxField);
            this.Controls.Add(this.comboBoxOpponent);
            this.Controls.Add(this.comboBoxTeam);
            this.Name = "WedstrijdInplannen";
            this.Text = "WedstrijdInplannen";
            this.Load += new System.EventHandler(this.WedstrijdInplannen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseFcBalOpHetDakDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.matchBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonMatchday;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxTime;
        private System.Windows.Forms.ComboBox comboBoxField;
        private System.Windows.Forms.ComboBox comboBoxOpponent;
        private System.Windows.Forms.ComboBox comboBoxTeam;
        private System.Windows.Forms.Button buttonBackToMain;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DatabaseFcBalOpHetDakDataSet1 databaseFcBalOpHetDakDataSet1;
        private System.Windows.Forms.BindingSource matchBindingSource;
        private DatabaseFcBalOpHetDakDataSet1TableAdapters.MatchTableAdapter matchTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tijdstipDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tegenstanderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn teamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn veldDataGridViewTextBoxColumn;
        private System.Windows.Forms.DateTimePicker dateTimePickerMatchday;
    }
}