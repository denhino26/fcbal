﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FCBalOpHetDak
{
    public class MatchClass
    {
        public int ID { get; set; }
        public DateTime Datum { get; set; }
        public string Tijdstip { get; set; }
        public string Tegenstander { get; set; }
        public string Team { get; set; }
        public string Veld { get; set; }

        private static List<MatchClass> speelschema = new List<MatchClass>();




        public MatchClass(DateTime datum, string tijdstip, string tegenstander, string team, string veld)
        {
            Datum = datum;
            Tijdstip = tijdstip;
            Tegenstander = tegenstander;
            Team = team;
            Veld = veld;
        }




        public static bool speelschemaBijhouden(MatchClass nieuweWedstrijd)
        {

            bool teamHeeftWedstrijd = speelschema.Any(w => w.Team == nieuweWedstrijd.Team && w.Datum == nieuweWedstrijd.Datum);


            bool veldBezet = speelschema.Any(w => w.Veld == nieuweWedstrijd.Veld && w.Datum == nieuweWedstrijd.Datum && w.Tijdstip == nieuweWedstrijd.Tijdstip);

            if (teamHeeftWedstrijd)
            {
                MessageBox.Show("Dit team heeft al een wedstrijd op deze dag.");
                return false;
            }

            if (veldBezet)
            {
                MessageBox.Show("Het veld is al bezet op dit tijdstip.");
                return false;
            }


            speelschema.Add(nieuweWedstrijd);
            MessageBox.Show("Wedstrijd toegevoegd!");
            return true;
        }
    }
}
