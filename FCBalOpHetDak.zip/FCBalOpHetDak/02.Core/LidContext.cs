﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FCBalOpHetDak._02.Core
{
    internal class LidContext
    {
    }
}
