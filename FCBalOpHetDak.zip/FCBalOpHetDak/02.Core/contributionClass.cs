﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace FCBalOpHetDak
{
    public class Contributiebetaling
    {
        public int ID { get; set; }
        public int LidID { get; set; }
        public decimal Bedrag { get; set; }
        public DateTime Betaaldatum { get; set; }
        public string Status { get; set; }
        private string connectionString;

        public Contributiebetaling(int id, int lidId, decimal bedrag, string connString)
        {
            ID = id;
            LidID = lidId;
            Bedrag = bedrag;
            Betaaldatum = DateTime.Now;
            Status = "Openstaand";
            connectionString = connString;
        }

        public void BetaalContributie()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {

                conn.Open();


                string totalQuery = "SELECT SUM(Bedrag) FROM Contribution WHERE LidID = @LidID";
                SqlCommand totalCmd = new SqlCommand(totalQuery, conn);
                totalCmd.Parameters.AddWithValue("@LidID", LidID);
                object result = totalCmd.ExecuteScalar();
                decimal totaalBedrag = result != DBNull.Value ? Convert.ToDecimal(result) : 0;
                totaalBedrag += Bedrag;


                string status = totaalBedrag >= TeamManager.ContributioDrempel ? "Betaald" : "Openstaand";


                string insertQuery = "INSERT INTO Contribution (LidID, Bedrag, Betaaldatum, Status) VALUES (@LidID, @Bedrag, @Datum, @Status)";
                using (SqlCommand insertCmd = new SqlCommand(insertQuery, conn))
                {
                    insertCmd.Parameters.AddWithValue("@LidID", LidID);
                    insertCmd.Parameters.AddWithValue("@Bedrag", Bedrag);
                    insertCmd.Parameters.AddWithValue("@Datum", Betaaldatum);
                    insertCmd.Parameters.AddWithValue("@Status", status);
                    insertCmd.ExecuteNonQuery();
                }


                string updateQuery = "UPDATE Member SET Status = @Status WHERE ID = @LidID";
                using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                {
                    updateCmd.Parameters.AddWithValue("@LidID", LidID);
                    updateCmd.Parameters.AddWithValue("@Status", status);
                    updateCmd.ExecuteNonQuery();
                }

                MessageBox.Show("Betaling verwerkt!");


            }
        }
    }
}
