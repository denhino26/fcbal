﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FCBalOpHetDak
{
    public static class TeamManager
    {
        public static List<string> Teams { get; } = new List<string>
        {
            "Team 1",
            "Team 2",
            "Team 3",
            "Team 4"
        };

        public static List<string> Fields { get; } = new List<string>
        {
            "Hoofdveld",
            "Veld 1"
        };

        public static List<string> Time { get; } = new List<string>
        {
            "19:00",
            "20:00",
            "21:00"


        };

        public static List<decimal> BetalingVerwerken { get; } = new List<decimal>
        {
           25,
           50
        };

        public static decimal ContributioDrempel { get; } = 100m;

    }

}
