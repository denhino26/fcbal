﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace FCBalOpHetDak
{
    public class Lid
    {
        public int ID { get; set; }
        public string Naam { get; set; }
        public int Geboortejaar { get; set; }
        public string Email { get; set; }
        public string Team { get; set; }
        public string Status { get; private set; }
        public bool ContributieBetaald { get; private set; }

        private string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\denni\\source\\repos\\FCBalOpHetDak\\FCBalOpHetDak\\03.Database\\DatabaseFcBalOpHetDak.mdf;Integrated Security=True;Connect Timeout=30";

        public Lid() { }

        public Lid(string naam, int geboortejaar, string team, string email, string status)
        {
            Naam = naam;
            Geboortejaar = geboortejaar;
            Team = team;
            Email = email;
            Status = status;
            ContributieBetaald = false;
        }

        public void NewMember(string naam, int geboortejaar, string email, string team)
        {
            if (string.IsNullOrWhiteSpace(naam))
            {
                MessageBox.Show("Vul een naam in.");
                return;
            }

            if (geboortejaar <= 1950 || geboortejaar >= DateTime.Now.Year)
            {
                MessageBox.Show("Vul een geldig geboortejaar in.");
                return;
            }
            if (string.IsNullOrWhiteSpace(email))
            {
                MessageBox.Show("Vul een geldig e-mailadres in.");
                return;
            }
            if (string.IsNullOrWhiteSpace(team))
            {
                MessageBox.Show("Selecteer een team.");
                return;
            }

            string status = "Openstaand";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "INSERT INTO Member (Naam, Geboortejaar, Email, Team, Status) VALUES (@Naam, @Geboortejaar, @Email, @Team, @Status)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Naam", naam);
                    cmd.Parameters.AddWithValue("@Geboortejaar", geboortejaar);
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@Team", team);
                    cmd.Parameters.AddWithValue("@Status", status);

                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Lid succesvol toegevoegd!");
        }
    }
}
